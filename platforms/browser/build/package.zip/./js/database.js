var db;
var loggedIn;
var user = {};
var db_name = "smnf.db";

// Ouvre la base de données
function openDB() {
	if (window.sqlitePlugin) {
		db = window.sqlitePlugin.openDatabase({name: db_name});
	} else {
		db = window.openDatabase({name: db_name});
	}
	checkConnection();
}

// Détermine si l'utilisateur s'est déjà connecté auparavant, puis agit en conséquence
function checkConnection() {
	db.transaction(function (tx) {
		tx.executeSql("SELECT count(*) as cpt from users;", [], function (tx, res) {
			loggedIn = res.rows.item(0).cpt > 0;
			connectUser();
		});
	}, function (e) {
		loggedIn = false;
		connectUser();
	});
}

// Crée la base de données
function createDB() {
	db.transaction(function (tx) {
		tx.executeSql("DROP TABLE IF EXISTS users");
		tx.executeSql("CREATE TABLE IF NOT EXISTS users("
			+ "id integer primary key,"
			+ "data text)"
		);
	}, function (e) {
		alert("error create DB " + e.message);
	});
}

// Initialise l'utilisateur s'il est connecté, ou déclenche la procédure de connexion dans le cas contraire
function connectUser() {
	if (loggedIn) {
		initUser();
	} else {
		createDB();
		showModal('connectionModal', true);
	}
}

// Tente de se connecter sur le serveur de l'inventaire
function tryToConnect() {
	var login = $("#inputLogin");
	var password = $("#inputPassword");

	//TODO : connexion base de données en ligne
	addUser(login.val(), password.val(), "toto", "tata");
}

// Ajoute l'utilisateur à la base de données
function addUser(login, password, asso, role) {
	user.login = login;
	user.password = password;
	user.asso = asso;
	user.role = role;

	db.transaction(function (tx) {
		tx.executeSql("INSERT INTO users(data) VALUES (?)",
			[JSON.stringify(user)], function (tx, res) {alert("adding user " + res.insertId);});
	}, function (e) {
		alert("error addUser " + e.message);
	});
	goBack();
}

// Initialise l'utilisateur depuis la base de données
function initUser() {
	db.transaction(function (tx) {
		tx.executeSql("SELECT data from users;", [], function(tx, res) {
			user = JSON.parse(res.rows.item(0).data);
		});
	}, function (e) {
		alert("error initUser " + e.message);
	});
}