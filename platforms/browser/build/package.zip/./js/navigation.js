function beginRecolt() {
	generateNewForm($("#cameraPic").attr('src'));
	goBack();
	showPage('add_recolt');
}

function loadRecolt(id) {
	generateFormFromId(id);
	goBack();
	showPage('add_recolt');
}

/* 
Fonction gérant la transition entre les pages
@param id : id de la div à afficher 
*/
function showPage(id) {
	if (id == "index")
		previousPages = [];
	else 
		previousPages.push($(".page").filter(":visible").attr("id"));
	changePage(id);
}

/*
Fonction affichant la div d'id id et cachant les autres.
@param id : id de la div à afficher
*/
function changePage(id) {
	$(".page").each(function(i, div) {
		$(this).hide();
	});
	$("#" + id).show();
	currentPage = id;
}

/*
Fonction permettant de reculer d'une page dans la hiérarchie
*/
function goBack() {
	var previous = previousPages.pop();
	if (!previous) {
		navigator.app.exitApp();
	}
	showPage(previous);
}