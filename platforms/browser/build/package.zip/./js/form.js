/*
Fonction permettant de remplir les suggestions de l'input dont l'id
est passé en paramètre
@param array: suggestions possibles
@param id : id de l'input auquel on ajoute les suggestions
*/
function populateInput(array, id) {
    var data = document.getElementById(id);
    
    var options = "";
    for (var i = 0; i < array.length; i++) {
        options += "<option value='" + array[i] + "'/>";
    }
    data.innerHTML = options;
}

/*
Fonction permettant de remplir les propositions du select dont 
l'id est passé en paramètre
@param array : propositions possibles
@param id : id du select auquel on ajoute les propositions
*/
function populateSelect(array, id) {
    var list = document.getElementById(id);
    /*var list = $("#"+id);*/

    var options = "";
    for (var i = 0; i < array.length; ++i) {
        options += "<option>" + array[i] + "</option>";
    }
    list.innerHTML = options;
}

function populateFields() {
    setDate();
    setLocation();
    var array = [];
    array.push('');
    array.push('toto 1iubhigbugvugfvuyvuvu');
    array.push('toto 2');
    array.push('toto 3');
    array.push('titi 1');
    array.push('titi 2');
    array.push('titi 3');
    array.push('42');

    var arraySVF = [];
    arraySVF.push('');
    arraySVF.push('var.');
    arraySVF.push('ssp.');
    arraySVF.push('f.');

    populateSelect(arraySVF, 'listSVF');

    var selectsArray = [];
    selectsArray.push('listPhylum');
    selectsArray.push('listModulation');
    selectsArray.push('listRH');
    selectsArray.push('listSubstrate');
    selectsArray.push('listHost');
    selectsArray.push('listHostState');
    selectsArray.push('listLegNumber');
    selectsArray.push('listLegatees');
    selectsArray.push('listDetNb');
    selectsArray.push('listDet');

    selectsArray.forEach(function(select) {
     populateSelect(array, select);
 });

    var inputsArray = [];
    inputsArray.push('dataGenre');
    inputsArray.push('dataSpecies');
    inputsArray.push('dataEpithete');
    inputsArray.push('dataAuthor');
    inputsArray.push('dataHC');

    inputsArray.forEach(function(input) {
     populateInput(array, input);
 });

}

function setDate() {
    $("#date").text(new Date().toString());
}

function setLocation() {
    calculatePosition();
}

function generateNewForm(imageSrc) {
    populateFields();
    
    if (imageSrc)
        addPicture(imageSrc);
}

function generateFormFromId(id) {
    //TODO : Charger depuis la BDD la recolte plutôt qu'un nouveau formulaire
    generateNewForm();
}