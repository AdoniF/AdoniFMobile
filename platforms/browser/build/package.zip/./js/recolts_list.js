//Fonction permettant d'ajouter une récolte dans la table des récoltes
function addRecolt(src, phylum) {
	var table = $("#table").children("tbody");
	var newRow = "<tr><td><div class='row'><div class='col-sm-4 vcenter hidden-xs'>"
		+ "<img class='img-thumbnail' id='recolt' src='" + src + "' alt='picture'/></div>"
		+ "<div class='col-xs-4 col-sm-2 vcenter'>" + phylum + "</div>"
		+ "<div class='col-xs-offset-0 col-xs-8 col-sm-offset-2 col-sm-4 vcenter'>"
		+ "<div class='row'>"
		+ "<div class='col-xs-6'><button type='button' class='btn btn-primary vcenter row-button'>Modifier</button></div>"
		+ "<div class='col-xs-6'><button type='button' class='btn btn-primary vcenter row-button'>Supprimer</button></div>"
		+ "</div></div></div></td></tr>";
	table.append(newRow);
}

